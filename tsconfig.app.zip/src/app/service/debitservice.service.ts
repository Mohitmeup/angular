import { Injectable } from '@angular/core';
import { Debitmodel } from '../model/debitmodel';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DebitserviceService {
  baseUrl: string;
  constructor(private http: HttpClient) {
    this.baseUrl = `${environment.baseMwUrl}/contact`;
  }

  getAll(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/debitlist`);
  }

  getDetails(cardNumber : number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/carddisplaymenu/${cardNumber}`);
  }
}
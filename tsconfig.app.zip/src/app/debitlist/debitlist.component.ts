import { Component} from '@angular/core';
import { Debitmodel } from '../model/debitmodel';
import { DebitserviceService } from '../service/debitservice.service';

@Component({
  selector: 'app-debitlist',
  templateUrl: './debitlist.component.html',
  styleUrls: ['./debitlist.component.css']
})
export class DebitlistComponent {

  bean: Debitmodel[];
  bean1: Debitmodel;
  constructor(private debitService: DebitserviceService) {
  }

  load() {
    console.log("enter1");
    this.debitService.getAll().subscribe(
      (data) => {
        console.log("enter");
        this.bean = data;
     
    }
      );
}

details(g : Debitmodel){
  this.debitService.getDetails(g.cardNumber).subscribe(
    (data) => {
      this.bean1 = data;
    }
  )
}
}
